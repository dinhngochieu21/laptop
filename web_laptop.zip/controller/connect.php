<?php
    $con = mysqli_connect('localhost','id13806736_hieu21','2aPh/ZP0%fg))IM7','id13806736_my_csdl') or die('Unable To connect');
?>