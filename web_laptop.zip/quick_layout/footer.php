<div class="ads"><img src="image/BBChuongTrinhVung-Desktop-4.0-1024x219.jpg" alt=""></div>

<div class="footer"></div>